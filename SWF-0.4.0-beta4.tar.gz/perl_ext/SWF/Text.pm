# ====================================================================
# Copyright (c) 2000-2001 by Soheil Seyfaie. All rights reserved.
# This program is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself.
# ====================================================================

# $Author: soheil $
# $Id: Text.pm,v 1.2 2001/09/24 01:01:47 soheil Exp $

package SWF::Text;
use SWF ();

$SWF::Text::VERSION = $SWF::VERSION;

1;

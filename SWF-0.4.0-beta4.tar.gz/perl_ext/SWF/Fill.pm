# ====================================================================
# Copyright (c) 2000-2001 by Soheil Seyfaie. All rights reserved.
# This program is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself.
# ====================================================================

# $Author: soheil $
# $Id: Fill.pm,v 1.2 2001/09/24 00:55:49 soheil Exp $

package SWF::Fill;
use SWF ();

$SWF::Fill::VERSION = $SWF::VERSION;

1;

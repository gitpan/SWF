# ====================================================================
# Copyright (c) 2000 by Soheil Seyfaie. All rights reserved.
# This program is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself.
# ====================================================================

# $Author: soheil $
# $Id: Gradient.pm,v 1.2 2001/09/24 00:57:16 soheil Exp $

package SWF::Gradient;
use SWF();

$SWF::Gradient::VERSION = $SWF::VERSION;


1;

#!/usr/bin/python
from ming import *

Ming_useSWFVersion(8);

m =  SWFMovie();

m.save("test06.swf");

# ====================================================================
# Copyright (c) 2000-2001 by Soheil Seyfaie. All rights reserved.
# This program is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself.
# ====================================================================

# $Author: soheil $
# $Id: Font.pm,v 1.2 2001/09/24 00:56:37 soheil Exp $

package SWF::Font;
use SWF();

$SWF::Font::VERSION = $SWF::VERSION;


1;

extern int run_test(SWFMovie m, const char *testname);

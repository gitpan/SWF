#!/usr/bin/php -c.
<?php
$m = new SWFMovie(8);


$m->save("test06.swf");
?>

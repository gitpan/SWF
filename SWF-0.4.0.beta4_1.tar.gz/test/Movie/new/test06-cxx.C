#include <mingpp.h>


main(){
class SWFMovie *m;
m = new SWFMovie(8);

m->save("test06.swf");
}
